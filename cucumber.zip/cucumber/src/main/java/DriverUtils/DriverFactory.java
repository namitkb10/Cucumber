package DriverUtils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverFactory {
	
	private WebDriver driver;
	
	public static ThreadLocal<WebDriver> tlDriver=new ThreadLocal<>();
	
	public WebDriver init_Driver(String browser)
	{
		if(browser.equals("chrome"))
		{
			tlDriver.set(new ChromeDriver());
		}
		else if(browser.equals("firefox"))
		{
			tlDriver.set(new FirefoxDriver());
		}
		else if(browser.equals("edge"))
		{
			tlDriver.set(new EdgeDriver());
		}
		else
		{
			System.out.println("Please pass the correct browser value");
		}
		
		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		return getDriver();
	}
	
	public static synchronized WebDriver getDriver()
	{
		return tlDriver.get();
	}

}