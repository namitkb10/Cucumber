package com.hcl.filereaders;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	private String filePath;
	private FileInputStream fip;
	private Workbook workbook;

	public ExcelReader(String filePath) throws EncryptedDocumentException, InvalidFormatException, IOException {
		this.filePath = filePath;
		fip = new FileInputStream(filePath);
		workbook = new XSSFWorkbook(fip);
	}

	public Sheet getSheet(String sheetName) {
		Sheet sheet = null;
		if (workbook != null) {
			sheet = workbook.getSheet(sheetName);
		}
		return sheet;
	}

	public Row getRow(String sheetName, int rowNum) {
		Row row = null;
		Sheet sheet = getSheet(sheetName);
		if (sheet != null) {
			row = sheet.getRow(rowNum);
		}
		return row;
	}

	public Cell getCell(String sheetName, int rowNum, int cellNum) {
		/*
		 * Sheet sheet = getSheet(sheetName); Row row = sheet.getRow(rowNum); Cell cell
		 * = row.getCell(cellNum); return cell;
		 */
		return getSheet(sheetName).getRow(rowNum).getCell(cellNum);
	}

	public String getSingleCellData(String sheetName, int rowNum, int cellNum) {
		String cellValue = null;
		Sheet sheet = getSheet(sheetName);
		Row row = sheet.getRow(rowNum);
		Cell cell = row.getCell(cellNum);
		if (cell.getCellType() == CellType.STRING) {
			cellValue = cell.getStringCellValue();
		} else if (cell.getCellType() == CellType.NUMERIC) {
			cellValue = cell.getNumericCellValue() + "";
		}
		return cellValue;
	}

	public List getTotalSheetData(String sheetName) {
		List sheetData = new ArrayList();
		Sheet sheet = getSheet(sheetName);
		for (int i = 0; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);

			for (int j = 0; j < row.getLastCellNum(); j++) {
				Cell cell = row.getCell(j);
				if (cell.getCellType() == CellType.NUMERIC) {
					double d = cell.getNumericCellValue();
					sheetData.add(d);
				} else if (cell.getCellType() == CellType.STRING) {
					String cellValue = cell.getStringCellValue();
					sheetData.add(cellValue);
				}
			}
		}
		return sheetData;
	}
	
	public int getRowCount(String sheetName) {
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1)
			return 0;
		else {
			Sheet sheet = workbook.getSheetAt(index);
			int number = sheet.getLastRowNum() + 1;
			return number;
		}

	}
	
	
	public String getCellData(String sheetName, String colName, int rowNum) {
		try {
			if (rowNum <= 0)
				return "";

			int index = workbook.getSheetIndex(sheetName);
			int col_Num = -1;
			if (index == -1)
				return "";

			Sheet sheet = workbook.getSheetAt(index);
			Row row = sheet.getRow(0);
			for (int i = 0; i < row.getLastCellNum(); i++) {
				// System.out.println(row.getCell(i).getStringCellValue().trim());
				if (row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
					col_Num = i;
			}
			if (col_Num == -1)
				return "";

			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				return "";
			Cell cell = row.getCell(col_Num);

			if (cell == null)
				return "";

			//System.out.println(cell.getCellType().name());
			//
			if (cell.getCellType().name().equals("STRING"))
				return cell.getStringCellValue();

			// if (cell.getCellType().STRING != null)

			// if(cell.getCellType()==Xls_Reader.CELL_TYPE_STRING)
			// return cell.getStringCellValue();
			else if ((cell.getCellType().name().equals("NUMERIC")) || (cell.getCellType().name().equals("FORMULA"))) {

				String cellText = String.valueOf(cell.getNumericCellValue());
				if (DateUtil.isCellDateFormatted(cell)) {
					// format in form of M/D/YY
					double d = cell.getNumericCellValue();

					Calendar cal = Calendar.getInstance();
					cal.setTime(DateUtil.getJavaDate(d));
					cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
					cellText = cal.get(Calendar.DAY_OF_MONTH) + "/" + cal.get(Calendar.MONTH) + 1 + "/" + cellText;

					// System.out.println(cellText);

				}

				return cellText;
			} else if (cell.getCellType().BLANK != null)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());

		} catch (Exception e) {

			e.printStackTrace();
			return "row " + rowNum + " or column " + colName + " does not exist in xls";
		}
	}

}
