package pageobjects;

import org.openqa.selenium.By;

public class HomePage {
	
	public By allMenus=By.xpath("//ul[@class='block-mainnavigationbt navnavbar-navlevel-0']//li//a");
	
	public By servicesSubMenus=By.xpath("//ul[@class='dropdown-menu level-1']//li//ul//li//a");
	
	public By remainSubMenus=By.xpath("//ul[@class='dropdown-menu level-1']//li//a");

}
