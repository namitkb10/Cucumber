package pageobjects;

import org.openqa.selenium.By;

public class ContactUsPage {
	
	public By contactUsLink=By.linkText("Contact Us");
	public By btnAllCookies=By.id("onetrust-accept-btn-handler");
	
	public By btnSubmit=By.id("edit-actions-submit");
	public By lblFullNameError=By.id("edit-full-name-error");
	
	public By lblEditCountry=By.id("edit-country-error");
	
	public By lblQueryTypeError=By.id("edit-query-type-error");
	
	public By lblCommentsError=By.id("edit-message-comments-error");
	
	public By lblPrivacyPolicyError=By.id("privacy_policy-error");
	
    public By lblEmailError=By.id("edit-email-address-error");
    
    public By tbEmail=By.id("edit-email-address");
	
	public By tbPhone=By.id("edit-phone");
	
	public By tbOrganization=By.id("edit-organization");
	
	public By lblPhoneError=By.id("edit-phone-error");
	
	
	

}
