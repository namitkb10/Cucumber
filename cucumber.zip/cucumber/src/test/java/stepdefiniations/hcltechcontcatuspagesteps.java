package stepdefiniations;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.hcl.filereaders.ExcelReader;


import AppHooks.ApplicationHooks;
import DriverUtils.DriverFactory;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageobjects.ContactUsPage;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class hcltechcontcatuspagesteps{

	public WebDriver driver=DriverUtils.DriverFactory.getDriver();
	
	ContactUsPage contactUsPage=new ContactUsPage();
	
	
	@When("Navigate to Contact us page and Validate the fields")
	public void navigate_to_contact_us_page_and_validate_the_fields() throws InterruptedException {
		driver.findElement(contactUsPage.contactUsLink).click();
		Thread.sleep(5000);
		driver.findElement(contactUsPage.btnAllCookies).click();
		driver.findElement(contactUsPage.btnSubmit).click();
		Thread.sleep(5000);
		Assert.assertEquals(driver.findElement(contactUsPage.lblFullNameError).getText(),
				"Full Name field is required.");
		Assert.assertEquals(driver.findElement(contactUsPage.lblEmailError).getText(),
				"Business Email Address field is required.");
		Assert.assertEquals(driver.findElement(contactUsPage.lblEditCountry).getText(), "Country field is required.");
		Assert.assertEquals(driver.findElement(contactUsPage.lblQueryTypeError).getText(),
				"Relationship to HCLTech field is required.");
		Assert.assertEquals(driver.findElement(contactUsPage.lblCommentsError).getText(),
				"How can we help you? field is required.");
		Assert.assertEquals(driver.findElement(contactUsPage.lblPrivacyPolicyError).getText(),
				"Privacy policy field is required.");
		driver.findElement(contactUsPage.tbEmail).sendKeys("mahesh");
		Assert.assertEquals(driver.findElement(contactUsPage.lblEmailError).getText(),
				"The value in Business Email Address is not a valid email address.");
		driver.findElement(contactUsPage.tbPhone).sendKeys("901001");
		driver.findElement(contactUsPage.tbOrganization).click();
		Assert.assertEquals(driver.findElement(contactUsPage.lblPhoneError).getText(),
				"Please enter at least 8 characters.");

	}

	@When("Enter form details")
	public void enter_form_details() throws EncryptedDocumentException, InvalidFormatException, IOException {

//		List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
//		driver.findElement(By.id("edit-full-name")).sendKeys(list.get(0).get("name"));
//		driver.findElement(By.id("edit-email-address")).clear();
//		driver.findElement(By.id("edit-email-address")).sendKeys(list.get(0).get("email"));
//		driver.findElement(By.id("edit-organization")).clear();
//		driver.findElement(By.id("edit-organization")).sendKeys(list.get(0).get("organization"));
//		driver.findElement(By.id("edit-phone")).clear();
//		driver.findElement(By.id("edit-phone")).sendKeys(list.get(0).get("phone"));
//		WebElement countryDD = driver.findElement(By.id("edit-country"));
//		Select selectCountry = new Select(countryDD);
//		selectCountry.selectByValue(list.get(0).get("country"));
//		WebElement relationshipDD = driver.findElement(By.id("edit-query-type"));
//		Select selectRelationship = new Select(relationshipDD);
//		selectRelationship.selectByValue(list.get(0).get("Relationship"));
//		driver.findElement(By.id("edit-message-comments")).sendKeys(list.get(0).get("Comments"));
		
		ExcelReader excelReader=
				new ExcelReader("D:\\Serenity2023\\cucumber\\TestData\\FormData.xlsx");
		String sheetName="HCLTECHDATA";
		System.out.println(excelReader.getRowCount(sheetName));
		for(int i=2;i<=excelReader.getRowCount(sheetName);i++)
		{
			String name=excelReader.getCellData(sheetName, "Name", i);
			String email=excelReader.getCellData(sheetName, "Email", i);
			String organization=excelReader.getCellData(sheetName, "Organization", i);
			String phone=excelReader.getCellData(sheetName, "Phone", i);
			String country=excelReader.getCellData(sheetName, "Country", i);
			String relationship=excelReader.getCellData(sheetName, "Relationship", i);
			String comments=excelReader.getCellData(sheetName, "Comments", i);
			
			driver.findElement(By.id("edit-full-name")).sendKeys(name);
			driver.findElement(By.id("edit-email-address")).clear();
			driver.findElement(By.id("edit-email-address")).sendKeys(email);
			driver.findElement(By.id("edit-organization")).clear();
			driver.findElement(By.id("edit-organization")).sendKeys(organization);
			driver.findElement(By.id("edit-phone")).clear();
			driver.findElement(By.id("edit-phone")).sendKeys(phone);
			WebElement countryDD = driver.findElement(By.id("edit-country"));
			Select selectCountry = new Select(countryDD);
			selectCountry.selectByValue(country);
			WebElement relationshipDD = driver.findElement(By.id("edit-query-type"));
			Select selectRelationship = new Select(relationshipDD);
			selectRelationship.selectByValue(relationship);
			driver.findElement(By.id("edit-message-comments")).sendKeys(comments);
			
		}
		

	}

	@When("Upload Request service contract file")
	public void upload_request_service_contract_file() throws AWTException, InterruptedException {

//		driver.findElement(By.id("edit-upload-multifile-upload"))
//				.sendKeys("D:\\Serenity2023\\cucumber\\src\\test\\resources\\UploadFiles\\JD.docx");
		
		driver.findElement(By.id("edit-upload-multifile--label")).click();
		Robot robot=new Robot();
		robot.delay(3000);
		StringSelection str=new StringSelection("D:\\Serenity2023\\cucumber\\src\\test\\resources\\UploadFiles\\JD.docx");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		


	}

}
